package com.model;

import java.sql.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class Ticket {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int ticket_id;
	private int counter;
	private String pnr;
	private Date travel_date;
	
	@OneToMany(targetEntity = Passenger.class,cascade = CascadeType.ALL)
	@JoinColumn(name = "pt_fk",referencedColumnName = "ticket_id")
	private List<Passenger> passengers;
	
	@OneToMany(targetEntity = Train.class,cascade = CascadeType.ALL)
	@JoinColumn(name = "tt_fk",referencedColumnName = "ticket_id")
	private List<Train> trains;

	public int getTicket_id() {
		return ticket_id;
	}

	public void setTicket_id(int ticket_id) {
		this.ticket_id = ticket_id;
	}

	public int getCounter() {
		return counter;
	}

	public void setCounter(int counter) {
		this.counter = counter;
	}

	public String getPnr() {
		return pnr;
	}

	public void setPnr(String pnr) {
		this.pnr = pnr;
	}

	public Date getTravel_date() {
		return travel_date;
	}

	public void setTravel_date(Date travel_date) {
		this.travel_date = travel_date;
	}

	public List<Passenger> getPassengers() {
		return passengers;
	}

	public void setPassengers(List<Passenger> passengers) {
		this.passengers = passengers;
	}

	public List<Train> getTrains() {
		return trains;
	}

	public void setTrains(List<Train> trains) {
		this.trains = trains;
	}

	@Override
	public String toString() {
		return "Ticket [ticket_id=" + ticket_id + ", counter=" + counter + ", pnr=" + pnr + ", travel_date="
				+ travel_date + ", passengers=" + passengers + ", trains=" + trains + "]";
	}

	public Ticket(int ticket_id, int counter, String pnr, Date travel_date, List<Passenger> passengers,
			List<Train> trains) {
		super();
		this.ticket_id = ticket_id;
		this.counter = counter;
		this.pnr = pnr;
		this.travel_date = travel_date;
		this.passengers = passengers;
		this.trains = trains;
	}

	public Ticket() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	
}
