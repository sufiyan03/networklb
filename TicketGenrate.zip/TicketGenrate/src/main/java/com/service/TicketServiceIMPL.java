package com.service;


import com.model.PassengerModel;
import com.model.TicketModel;
import com.model.TrainModel;
import com.repo.PassengerRepository;
import com.repo.TicketRepository;
import com.repo.TrainRepository;
import com.util.UserData;


import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class TicketServiceIMPL implements TicketService {
	
	

	@Autowired
	private TicketRepository ticketrepo;
	@Autowired
	private TrainRepository trainrepo;
	private TicketModel ticket;

    private TrainModel train;
    private TreeMap<PassengerModel, Double> passengers = new TreeMap<PassengerModel,Double>();
    
    private int counter=100;
    
	@Override
	public String generatePNR(UserData users) throws IOException{
		train=trainrepo.findByTrainNumber(users.getTrain_no());
		if(train==null) {
			return "Train Number Entered is invalid";
			
		}
		Date current_date = new Date();
		if(users.getTravel_date().before(current_date)) {
		return "Travel Date is before current date";
		}
		SimpleDateFormat DateFor = new SimpleDateFormat("yyyyMMdd");
		String date = DateFor.format(users.getTravel_date());
		String pnr=Character.toString(train.getSource().charAt(0)) +
                   Character.toString(train.getDestination().charAt(0)) + "_" +
                   date+
                  ++counter;
		        for(PassengerModel p:users.getPass()) {
		        	addPassenger(p);
		        }
		        Double totalprice = calTotalPrice(passengers);
		        
		        ticket=new TicketModel();
		        ticket.setPassengers(users.getPass());
		        ticket.setDate(users.getTravel_date());
		        ticket.setPnr(pnr);
		        ticket.setTrain(train);
		        ticketrepo.save(ticket);
		        System.out.println(passengers);
		        Path p = Paths.get("C:\\genrateTicket\\"+pnr+".txt");
		    	if (Files.exists(p)){
		    	Files.delete(p);
		    	}
		    	SimpleDateFormat DateforFile = new SimpleDateFormat("dd/MM/yyyy");
		    	String Filedate = DateforFile.format(users.getTravel_date());
		    	p = Files.createFile(p);
		    	Files.write(p,("PNR: " + pnr + "\n").getBytes(),StandardOpenOption.APPEND);
		    	Files.write(p,("Train NO: " +train.getTrain_no() +"\n").getBytes(),StandardOpenOption.APPEND);
		    	Files.write(p,("Train Name: " + train.getTrain_name().replace("\n", " ") + "\n").getBytes(),StandardOpenOption.APPEND);
		    	Files.write(p,("From: " + train.getSource() + "\n").getBytes(),StandardOpenOption.APPEND);
		    	Files.write(p,("To: " +train.getDestination() + "\n").getBytes(),StandardOpenOption.APPEND);
		    	Files.write(p,("Travel Date: " + Filedate + "\n").getBytes(),StandardOpenOption.APPEND);
		    	Files.write(p,("\n").getBytes(),StandardOpenOption.APPEND);
		    	Files.write(p,("Passengers:\n").getBytes(),StandardOpenOption.APPEND);
		    	Files.write(p,("name"+"\t"+"\t"+"\t"+"age"+"\t"+"\t"+"gender"+"\t"+"\t"+"fare"+"\n").getBytes(),StandardOpenOption.APPEND);
		    	for(Map.Entry<PassengerModel,Double> e :
		    	passengers.entrySet()) {
		    	Files.write(p,(e.getKey().getName()+" \t"+e.getKey().getAge()+"\t\t "+e.getKey().getGender()+"\t\t "+e.getValue()+"\n").getBytes(),StandardOpenOption.APPEND);
		    	}
		    	Files.write(p,("Total Price:"+totalprice).getBytes(),StandardOpenOption.APPEND);
		         return pnr;
		        
	}
	private Double calTotalPrice(TreeMap<PassengerModel, Double> passengers) {
		Double total = 0.0;
		for(Map.Entry<PassengerModel,Double> e:
			passengers.entrySet()) {
			total=total+e.getValue();
		}
		
		return total;
	}
	public Double calculateFare(PassengerModel pass) {
		
		 if (pass.getAge() <= 12)
	        {
	            return train.getTicket_price() * 0.5;
	        }
	        if (pass.getAge() >= 60)
	        {
	            return train.getTicket_price() *0.6;
	        }
	        if (pass.getGender() == 'F' || pass.getGender() =='f')
	        {
	            return train.getTicket_price() * 0.75;
	        } else{
	            return train.getTicket_price();
	        }

}
	public void addPassenger(PassengerModel pass){
        passengers.put(pass,calculateFare(pass));
    }
	@Override
	public List<TicketModel> gettickets() {
		return ticketrepo.findAll();
	}
	

	
}
