package com.service;


import java.io.IOException;
import java.util.List;

import com.model.PassengerModel;

import com.model.TicketModel;
import com.util.UserData;

public interface TicketService {
	String generatePNR(UserData users) throws IOException;
	public List<TicketModel> gettickets();
}
