package com.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.model.PassengerModel;

public interface PassengerRepository extends JpaRepository<PassengerModel,Long> {

}
