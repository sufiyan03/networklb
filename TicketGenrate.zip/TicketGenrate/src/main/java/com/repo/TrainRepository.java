package com.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.model.TrainModel;

public interface TrainRepository extends JpaRepository<TrainModel,Long> {

	@Query("SELECT t FROM TrainModel t WHERE t.train_no = ?1")
	TrainModel findByTrainNumber(Long train_no);
}
