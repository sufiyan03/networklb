package com.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.model.TicketModel;


public interface TicketRepository extends JpaRepository<TicketModel,Long>{

	
	
}
