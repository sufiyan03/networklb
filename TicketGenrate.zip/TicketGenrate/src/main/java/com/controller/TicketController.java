package com.controller;
import java.io.IOException;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.model.PassengerModel;
import com.model.TicketModel;
import com.service.*;

import com.util.UserData;


@RestController
@RequestMapping("/aris")
public class TicketController {
	@Autowired
	private TicketService ticketService;
	
	
	
	
	public TicketController(TicketService ticketService) {
		super();
		this.ticketService = ticketService;
	}

	
	@GetMapping("/getall")
	public List<TicketModel> findAllTickets(){
		return ticketService.gettickets();
	}
	
	@PostMapping("/get")
	public String save(@RequestBody UserData users) throws IOException{
		return (ticketService.generatePNR(users));
	}
	
}
