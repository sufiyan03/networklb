package com.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="passengers")
public class PassengerModel implements Comparable{
 
    @Override
	public String toString() {
		return "PassengerModel [pid=" + pid + ", age=" + age + ", name=" + name + ", gender=" + gender + "]";
	}
	public long getPid() {
		return pid;
	}
	public void setPid(long pid) {
		this.pid = pid;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="pid")
    private long pid;
    @Column(name="page")
	private int age;
    @Column(name="pname")
	private String name;
    @Column(name="pgender")
	private char gender;
	@Override
	public int compareTo(Object o) {
		if (((PassengerModel) o).getName().toUpperCase().compareTo(getName().toUpperCase()) == 0){
		return 1;
		}
		else{
		return -1;
		}
		}
		
	}
	


