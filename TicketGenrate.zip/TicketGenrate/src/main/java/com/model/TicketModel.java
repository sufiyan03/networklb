package com.model;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="Ticket")
public class TicketModel {
 


	  @Override
	public String toString() {
		return "TicketModel [ticket_id=" + ticket_id + ", pnr=" + pnr + ", date=" + date + ", train=" + train
				+ ", passengers=" + passengers + "]";
	}

	public long getTicket_id() {
		return ticket_id;
	}

	public void setTicket_id(long ticket_id) {
		this.ticket_id = ticket_id;
	}

	public String getPnr() {
		return pnr;
	}

	public void setPnr(String pnr) {
		this.pnr = pnr;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public TrainModel getTrain() {
		return train;
	}

	public void setTrain(TrainModel train) {
		this.train = train;
	}

	public List<PassengerModel> getPassengers() {
		return passengers;
	}

	public void setPassengers(List<PassengerModel> passengers) {
		this.passengers = passengers;
	}

	@Id
	  @GeneratedValue(strategy=GenerationType.IDENTITY)
	  @Column(name="ticket_id")
	  private long ticket_id;
	  
	  @Column(name="pnr")
	  private String pnr;
	  
	  @Column
	  private Date date;
	  
	  @OneToOne(cascade = CascadeType.ALL)
	  private TrainModel train;
	  
	  @OneToMany(cascade = CascadeType.ALL)
	  @JoinTable(name = "Ticket_Passenger", joinColumns = { @JoinColumn(name = "ticket_id") }, inverseJoinColumns = { @JoinColumn(name = "p_id") })
	  
	  private List<PassengerModel> passengers;
	  
	  
	
}

