package com.util;

import java.util.Date;
import java.util.List;

import com.model.PassengerModel;

public class UserData {
public UserData(long train_no, Date travel_date, List<PassengerModel> pass) {
		super();
		this.train_no = train_no;
		this.travel_date = travel_date;
		this.pass = pass;
	}
@Override
	public String toString() {
		return "UserData [train_no=" + train_no + ", travel_date=" + travel_date + ", pass=" + pass + "]";
	}
public long getTrain_no() {
		return train_no;
	}
	public void setTrain_no(long train_no) {
		this.train_no = train_no;
	}
	public Date getTravel_date() {
		return travel_date;
	}
	public void setTravel_date(Date travel_date) {
		this.travel_date = travel_date;
	}
	public List<PassengerModel> getPass() {
		return pass;
	}
	public void setPass(List<PassengerModel> pass) {
		this.pass = pass;
	}
private long train_no;
private Date travel_date;
private List<PassengerModel> pass;

}
